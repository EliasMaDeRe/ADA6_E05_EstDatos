import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class MergeSortCSV {

    private DoublyLinkedList<CSVData> listaEnlazada;
    private int numeroDeIntercambios;
    private int numeroDeComparaciones;
    private double tiempoDeEjecucion;
    private String columna;
    private String NOMBRE_ORDENAMIENTO = "MergeSort";
    private Boolean ascendente;

    public MergeSortCSV() {
        listaEnlazada = new DoublyLinkedList<CSVData>();
        numeroDeIntercambios = 0;
        numeroDeComparaciones = 0;
    }



    DoublyLink<CSVData> merge(DoublyLink<CSVData> first, DoublyLink<CSVData> second)
    {
        // If first linked list is empty
        if (first == null) {
            return second;
        }
 
        // If second linked list is empty
        if (second == null) {
            return first;
        }
 
        // Pick the smaller value
        numeroDeComparaciones++;
        if(ascendente){
            if (first.dData.getAttribute(this.columna) < second.dData.getAttribute(this.columna)) {
                first.next = merge(first.next, second);
                first.next.prev = first;
                first.prev = null;
                return first;
            }
            else {
                second.next = merge(first, second.next);
                second.next.prev = second;
                second.prev = null;
                return second;
            }
        }else{
            if (first.dData.getAttribute(this.columna) > second.dData.getAttribute(this.columna)) {
                first.next = merge(first.next, second);
                first.next.prev = first;
                first.prev = null;
                return first;
            }
            else {
                second.next = merge(first, second.next);
                second.next.prev = second;
                second.prev = null;
                return second;
            }
        }
    }

    public DoublyLink<CSVData> split(DoublyLink<CSVData> head)
    {
        DoublyLink<CSVData> fast = head, slow = head;
        while (fast.next != null
               && fast.next.next != null) {
            fast = fast.next.next;
            slow = slow.next;
        }
        DoublyLink<CSVData> temp = slow.next;
        slow.next = null;
        return temp;
    }
 

    public DoublyLink<CSVData> mergeSort(DoublyLink<CSVData> node)
    {
        if (node == null || node.next == null) {
            return node;
        }
        DoublyLink<CSVData> second = split(node);
 
        // Recur for left and right halves
        node = mergeSort(node);
        second = mergeSort(second);
 
        // Merge the two sorted halves
        return merge(node, second);
    }
    

    private CSVData createCSVLink(String line) {
        String[] lineArray = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
        int serialNumber = Integer.parseInt(lineArray[0]);
        String country = lineArray[1];
        long[] restOfAttributes = new long[6];

        for (int i = 2; i < lineArray.length; i++) {
            if (lineArray[i].equals("") || lineArray[i].equals("N/A")) {
                restOfAttributes[i - 2] = 0;
            } else {
                String numberWithoutCommas = lineArray[i].replaceAll(",", "").replaceAll("\"", "");
                restOfAttributes[i - 2] = Long.parseLong((numberWithoutCommas));
            }
        }

        return new CSVData(serialNumber, country, restOfAttributes[0], restOfAttributes[1], restOfAttributes[2],
                restOfAttributes[3], restOfAttributes[4], restOfAttributes[5]);
    }

    private void exportCSV(DoublyLink<CSVData> head) {
        File csvFile = new File("../csv's/"+NOMBRE_ORDENAMIENTO+"_ordenado.csv");
        try (FileWriter csvWriter = new FileWriter(csvFile);) {
            csvWriter.write(
                    "Serial Number,Country,Total Cases,Total Deaths,Total Recovered,Active Cases,Total Test,Population\n");
            DoublyLink<CSVData> curr = head;
            while (curr.next != null) {
                csvWriter.write(curr.dData + "\n");
                curr = curr.next;
            }
            csvWriter.write(curr.dData.toString());
            csvWriter.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    private void exportMetrics() {
        File metricsFile = new File("../metricas/Metricas.txt");
        try {
            FileWriter writer = new FileWriter(metricsFile,true);
            writer.write("Sort: MergeSort \n");
            writer.write("Tiempo de ejecucion: " + tiempoDeEjecucion + " segundos" + "\n");
            writer.write("Numero de comparaciones: " + numeroDeComparaciones + "\n");
            writer.write("Numero de intercambios: " + numeroDeIntercambios + "\n");
            writer.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

    public void sort(String columna, Boolean ascendente) {
        this.columna = columna;
        this.ascendente = ascendente;
        long tiempoDeInicio = System.nanoTime();
        DoublyLink<CSVData> newhead = mergeSort(listaEnlazada.findFirst());
        listaEnlazada.clear();
        long tiempoFinal = System.nanoTime();

        tiempoDeEjecucion = (tiempoFinal - tiempoDeInicio) / 1E9;
        exportCSV(newhead);
        exportMetrics();
    }

    public void loadCSV(String filename) {
        
        listaEnlazada.clear();

        File csvFile = new File(filename);
        try (Scanner csvReader = new Scanner(csvFile);) {
            csvReader.nextLine();
            while (csvReader.hasNext()) {
                String linea = csvReader.nextLine();
                CSVData newLink = createCSVLink(linea);
                listaEnlazada.insertAfter(newLink);
            }
            csvReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error: Archivo " + filename + " no encontrado");
        }
    }

    public void display() {
        listaEnlazada.displayList();
    }

}
