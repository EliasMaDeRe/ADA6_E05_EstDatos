public class CSVData {
    /**
     * Dataclass para ordenar el documento csv "covid_worldwide"
     * 
     */

    private int serialNumber;
    private String country;
    private long totalCases;
    private long totalDeaths;
    private long totalRecovered;
    private long activeCases;
    private long totalTest;
    private long population;

    public CSVData(int serialNumber, String country, long totalCases, long totalDeaths, long totalRecovered,
            long activeCases, long totalTest, long population) {
        this.serialNumber = serialNumber;
        this.country = country;
        this.totalCases = totalCases;
        this.totalDeaths = totalDeaths;
        this.totalRecovered = totalRecovered;
        this.activeCases = activeCases;
        this.totalTest = totalTest;
        this.population = population;
    }

    public int getSerialNumber() {
        return serialNumber;
    }

    public String getCountry() {
        return country;
    }

    public long getTotalCases() {
        return totalCases;
    }

    public long getTotalDeaths() {
        return totalDeaths;
    }

    public long getTotalRecoverd() {
        return totalRecovered;
    }

    public long getActiveCases() {
        return activeCases;
    }

    public long getTotalTest() {
        return totalTest;
    }

    public long getPopulation() {
        return population;
    }

    public long getAttribute(String atributo) {
        switch (atributo) {
            case "totalCasos":
                return totalCases;
            case "totalMuertes":
                return totalDeaths;
            case "totalRecuperados":
                return totalRecovered;
            default:
                return totalCases;
        }
    }

    @Override
    public String toString() {
        return String.valueOf(serialNumber) + "," + country + "," + String.valueOf(totalCases) + ","
                + String.valueOf(totalDeaths) + "," + String.valueOf(totalRecovered) + "," + String.valueOf(activeCases)
                + "," + String.valueOf(totalTest) + "," + String.valueOf(population);
    }
}
