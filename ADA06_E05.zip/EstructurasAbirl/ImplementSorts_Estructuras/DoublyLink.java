public class DoublyLink<T> {
    /**
     * Clase que sirve de nodo para DoublyLink<T>
     * 
     * @see DoublyLinkedList<T>
     */
    public T dData;
    public DoublyLink<T> next;
    public DoublyLink<T> prev;

    public DoublyLink(T dd) {
        dData = dd;
    }

    public void displayLink() {
        System.out.print("{" + dData + "} ");
    }
}