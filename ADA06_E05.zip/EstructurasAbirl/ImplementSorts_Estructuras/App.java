import java.io.File;
import java.util.Scanner;

public class App {
    /**
     * Clase main encargada de recibir el input del usuario y ordenar en base al
     * input.
     * 
     * 
     * @param args
     * @author Carlos Calderon
     * @author Elias Madera de Regil
     */
    public static String FILENAME = "../csv's/covid_worldwide.csv";
    public static BinaryInsertionSortCSV bis = new BinaryInsertionSortCSV();
    public static MergeSortCSV ms = new MergeSortCSV();
    public static QuickSortCSV qs;
    public static RadixSortCSV rs;
    
    public static void main(String[] args) {
        bis.loadCSV(FILENAME);

        ms.loadCSV(FILENAME);
        boolean ascendente = true;
        Scanner scan = new Scanner(System.in);
        System.out.println(
                "Algoritmo para ordenar el csv 'covid_worldwide' por una columna en particular, maximo de 3 opciones.");
        while (true) {
            System.out.println("Algoritmo de ordenamiento: BinaryInsertionSort,MergeSort,QuickSort,RadixSort");
            System.out.println("Estructura de datos en la que se ordena: Listas Doblemente ligadas");

            while(true){
                System.out.println("Ingrese 1 para un ordenamiento no decreciente o 0 para un ordenamiento no ascendente, DEFAULT : ASCENDENTE");
                int choiceA = scan.nextInt();
                if(choiceA ==  0){
                    ascendente = false;
                    break;
                }
                if(choiceA == 1){
                    ascendente = true;
                    break;
                }else{
                    System.out.println("Ingresa una opcion valida.");
                }
            }

            System.out.println("Ingrese 0 si desea salir del programa");
            System.out.println("Ingrese 1 si desea ordenar el csv por la columna 'Total Cases'");
            System.out.println("Ingrese 2 si desea ordenar el csv por la columna 'Total Deaths'");
            System.out.println("Ingrese 3 si desea ordenar el csv por la columna 'Total Recovered'");

            try {
                int choice = scan.nextInt();
                System.out.print("\n");
                System.out.print("\n");
                if (choice == 0) {
                    break;
                } else if (sortByColumn(choice,ascendente)) {
                    System.out.println("El csv ha sido ordenado!");
                    System.out.println("Revise la carpeta 'csv's' para ver el resultado");
                } else {
                    System.out.println("Porfavor, ingrese una opcion valida");
                }
            } catch (Exception e) {
                System.out.print("\n");
                System.out.print("\n");
                e.printStackTrace();
            }
        }
        scan.close();
    }

    public static boolean sortByColumn(int choice,boolean ascendente) {
        boolean flag = false;
        File metricsFile = new File("../metricas/Metricas.txt");
        
        metricsFile.delete();
        switch (choice) {
            
            case 1:
                System.out.println("ordenando por 'Total Cases'...");
                qs = new QuickSortCSV("totalCasos", ascendente);
                qs.loadCSV(FILENAME);
                rs = new RadixSortCSV(231,"totalCasos", ascendente);
                rs.loadCSV(FILENAME);
                ms.loadCSV(FILENAME);

                
                bis.sort("totalCasos", ascendente);
                ms.sort("totalCasos", ascendente);
                qs.sort();
                rs.sort();
                flag = true;
                break;
            case 2:
                System.out.println("ordenando por 'Total Deaths'");
                
                qs = new QuickSortCSV("totalMuertes", ascendente);
                qs.loadCSV(FILENAME);
                rs = new RadixSortCSV(231,"totalMuertes", ascendente);
                rs.loadCSV(FILENAME);
                ms.loadCSV(FILENAME);

                bis.sort("totalMuertes", ascendente);
                ms.sort("totalMuertes", ascendente);
                qs.sort();
                rs.sort();
                flag = true;
                break;
            case 3:
                System.out.println("ordenando por 'Total Recovered'");
                qs = new QuickSortCSV("totalRecuperados", ascendente);
                qs.loadCSV(FILENAME);
                rs = new RadixSortCSV(231,"totalRecuperados", ascendente);
                rs.loadCSV(FILENAME);
                ms.loadCSV(FILENAME);

                bis.sort("totalRecuperados", ascendente);
                ms.sort("totalRecuperados", ascendente);
                qs.sort();
                rs.sort();
                flag = true;
                break;
        }
        return flag;
    }

}
