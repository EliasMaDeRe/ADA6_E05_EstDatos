import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Arrays;;

public class RadixSortCSV {
    private CSVData[] array;
    private String atributo;
    private boolean ascendente;
    private int numeroDeIntercambios;
    private int numeroDeComparaciones;
    private double tiempoDeEjecucion;

    public RadixSortCSV(int size, String atributo, boolean ascendente) {
        array = new CSVData[size];
        this.ascendente = ascendente;
        this.atributo = atributo;
        numeroDeIntercambios = 0;
        numeroDeComparaciones = 0;
    }

    private CSVData createCSVData(String line) {
        String[] lineArray = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
        int serialNumber = Integer.parseInt(lineArray[0]);
        String country = lineArray[1];
        long[] restOfAttributes = new long[6];

        for (int i = 2; i < lineArray.length; i++) {
            if (lineArray[i].equals("") || lineArray[i].equals("N/A")) {
                restOfAttributes[i - 2] = 0;
            } else {
                String numberWithoutCommas = lineArray[i].replaceAll(",", "").replaceAll("\"", "");
                restOfAttributes[i - 2] = Long.parseLong((numberWithoutCommas));
            }
        }

        return new CSVData(serialNumber, country, restOfAttributes[0], restOfAttributes[1], restOfAttributes[2],
                restOfAttributes[3], restOfAttributes[4], restOfAttributes[5]);
    }

    public void loadCSV(String filename) {

        File csvFile = new File(filename);
        try (Scanner csvReader = new Scanner(csvFile);) {
            csvReader.nextLine();
            int i = 0;
            while (csvReader.hasNext()) {
                String linea = csvReader.nextLine();
                CSVData newLink = createCSVData(linea);
                array[i] = newLink;
                i++;
            }
            csvReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error: Archivo " + filename + " no encontrado");
            e.printStackTrace();
        }
    }

    private void exportCSV() {
        File csvFile = new File("../csv's/RadixSort_ordenado.csv");
        try (FileWriter csvWriter = new FileWriter(csvFile);) {
            csvWriter.write(
                    "Serial Number,Country,Total Cases,Total Deaths,Total Recovered,Active Cases,Total Test,Population\n");
            for (CSVData curr : array) {
                csvWriter.write(curr.toString() + "\n");
            }
            csvWriter.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    private void exportMetrics() {
        File metricsFile = new File("../metricas/Metricas.txt");
        try {
            FileWriter writer = new FileWriter(metricsFile,true);
            writer.write("Sort: RadixSort\n");
            writer.write("Tiempo de ejecucion: " + tiempoDeEjecucion + " segundos" + "\n");
            writer.write("Numero de comparaciones: " + numeroDeComparaciones + "\n");
            writer.write("Numero de intercambios: " + numeroDeIntercambios + "\n");
            writer.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

    public void sort() {
        long tiempoDeInicio = System.nanoTime();
        if (ascendente) {
            radixSortAscendente();
        } else {
            radixSortDescendente();
        }

        long tiempoFinal = System.nanoTime();

        tiempoDeEjecucion = (tiempoFinal - tiempoDeInicio) / 1E9;
        exportCSV();
        exportMetrics();
    }

    private void radixSortAscendente() {
        long maxNumber = getMaxNumber();
        for (int exp = 1; maxNumber / exp > 0; exp *= 10) {
            countingSortAscendente(exp);
        }
    }

    private long getMaxNumber() {
        long maxNumber = array[0].getAttribute(atributo);
        for (int i = 1; i < array.length; i++) {
            if (array[i].getAttribute(atributo) > maxNumber)
                maxNumber = array[i].getAttribute(atributo);
        }
        return maxNumber;

    }

    private void countingSortAscendente(int exp) {
        CSVData[] output = new CSVData[array.length];
        int[] count = new int[10];
        int i;

        for (i = 0; i < array.length; i++)
            count[(int) ((array[i].getAttribute(atributo) / exp) % 10)]++;

        for (i = 1; i < 10; i++)
            count[i] += count[i - 1];

        for (i = array.length - 1; i >= 0; i--) {
            output[(int) (count[(int) ((array[i].getAttribute(atributo) / exp) % 10)] - 1)] = array[i];
            count[(int) ((array[i].getAttribute(atributo) / exp) % 10)]--;
        }

        this.array = Arrays.copyOf(output, output.length);

    }

    private void radixSortDescendente() {
        long maxNumber = getMaxNumber();
        for (int exp = 1; maxNumber / exp > 0; exp *= 10) {
            countingSortDescendente(exp);
        }
    }

    private void countingSortDescendente(int exp) {
        CSVData[] output = new CSVData[array.length];
        int[] count = new int[10];
        int i;

        for (i = 0; i < array.length; i++)
            count[(int) (9 - (array[i].getAttribute(atributo) / exp) % 10)]++;

        for (i = 1; i < 10; i++)
            count[i] += count[i - 1];

        for (i = (array.length - 1); i >= 0; i--) {
            output[(int) (count[(int) (9 - ((array[i].getAttribute(atributo) / exp) % 10))] - 1)] = array[i];
            count[(int) (9 - (array[i].getAttribute(atributo) / exp) % 10)]--;
        }

        this.array = Arrays.copyOf(output, output.length);
    }

    public static void main(String[] args) {
        RadixSortCSV rs = new RadixSortCSV(231, "totalMuertes", false);
        rs.loadCSV("./csv's/covid_worldwide.csv");
        rs.sort();
    }
}
