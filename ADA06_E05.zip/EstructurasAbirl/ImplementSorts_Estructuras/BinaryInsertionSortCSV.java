import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class BinaryInsertionSortCSV {

    private ArrayList<CSVData> listaEnlazada;
    private int numeroDeIntercambios;
    private int numeroDeComparaciones;
    private double tiempoDeEjecucion;
    private String columna;
    private String NOMBRE_ORDENAMIENTO = "BinaryInsertionSort";
    private Boolean ascendente;

    public BinaryInsertionSortCSV() {
        listaEnlazada = new ArrayList<CSVData>();
        numeroDeIntercambios = 0;
        numeroDeComparaciones = 0;
    }

    private void binaryinsertionsort(int indiceInicialOrdenado, int indiceFinalOrdenado, int indiceRestoSinOrdenar) {
        while(indiceRestoSinOrdenar < listaEnlazada.size()){
            ordena(indiceInicialOrdenado, indiceFinalOrdenado, indiceRestoSinOrdenar);

            indiceFinalOrdenado++;
            indiceRestoSinOrdenar++;
        }
    }

    private void ordena(int indiceInicialOrdenado, int indiceFinalOrdenado , int indiceRestoSinOrdenar){

        int inicio = 0, fin = indiceFinalOrdenado, mid = (inicio+fin)/2;
        while(inicio <= fin){
            this.numeroDeComparaciones++;
            mid = (inicio+fin)/2;
            if(this.ascendente){
                if(listaEnlazada.get(mid).getAttribute(columna) <= listaEnlazada.get(indiceRestoSinOrdenar).getAttribute(columna)){
                    inicio = mid+1;
                }else{
                    fin = mid-1;
                }
            }else{
                if(listaEnlazada.get(mid).getAttribute(columna) < listaEnlazada.get(indiceRestoSinOrdenar).getAttribute(columna)){
                    fin = mid-1;
                }else{
                    inicio = mid+1;
                }                
            }

        }
        inserta(inicio,indiceFinalOrdenado,indiceRestoSinOrdenar);
    
        
    }

    private void inserta(int indice,int indiceFinalOrdenado, int indiceDeElemento){
        CSVData temp;
        while(indice <= indiceDeElemento){
            this.numeroDeIntercambios++;
            temp = listaEnlazada.get(indice);
            listaEnlazada.set(indice,listaEnlazada.get(indiceDeElemento));
            listaEnlazada.set(indiceDeElemento,temp);
            ++indice;
        }
    }

    private CSVData createCSVLink(String line) {
        String[] lineArray = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
        int serialNumber = Integer.parseInt(lineArray[0]);
        String country = lineArray[1];
        long[] restOfAttributes = new long[6];

        for (int i = 2; i < lineArray.length; i++) {
            if (lineArray[i].equals("") || lineArray[i].equals("N/A")) {
                restOfAttributes[i - 2] = 0;
            } else {
                String numberWithoutCommas = lineArray[i].replaceAll(",", "").replaceAll("\"", "");
                restOfAttributes[i - 2] = Long.parseLong((numberWithoutCommas));
            }
        }

        return new CSVData(serialNumber, country, restOfAttributes[0], restOfAttributes[1], restOfAttributes[2],
                restOfAttributes[3], restOfAttributes[4], restOfAttributes[5]);
    }

    private void exportCSV() {
        File csvFile = new File("../csv's/"+NOMBRE_ORDENAMIENTO+"_ordenado.csv");
        try (FileWriter csvWriter = new FileWriter(csvFile);) {
            csvWriter.write(
                    "Serial Number,Country,Total Cases,Total Deaths,Total Recovered,Active Cases,Total Test,Population\n");

            for(int i = 0; i < listaEnlazada.size(); ++i){
                csvWriter.write(listaEnlazada.get(i) + "\n");
            }
            csvWriter.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    private void exportMetrics() {
        File metricsFile = new File("../metricas/Metricas.txt");
        try {
            FileWriter writer = new FileWriter(metricsFile,true);
            writer.write("Sort: BinaryInsertionSort \n");
            writer.write("Tiempo de ejecucion: " + tiempoDeEjecucion + " segundos" + "\n");
            writer.write("Numero de comparaciones: " + numeroDeComparaciones + "\n");
            writer.write("Numero de intercambios: " + numeroDeIntercambios + "\n");
            writer.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

    public void sort(String columna, Boolean ascendente) {
        this.columna = columna;
        this.ascendente = ascendente;
        long tiempoDeInicio = System.nanoTime();
        binaryinsertionsort(0, 0, 1);
        long tiempoFinal = System.nanoTime();

        tiempoDeEjecucion = (tiempoFinal - tiempoDeInicio) / 1E9;
        exportCSV();
        exportMetrics();
    }

    public void loadCSV(String filename) {
        
        listaEnlazada.clear();

        File csvFile = new File(filename);
        try (Scanner csvReader = new Scanner(csvFile);) {
            csvReader.nextLine();
            while (csvReader.hasNext()) {
                String linea = csvReader.nextLine();
                CSVData newLink = createCSVLink(linea);
                listaEnlazada.add(newLink);
            }
            csvReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error: Archivo " + filename + " no encontrado");
        }
    }

    public void display() {
        for(int i = 0; i < listaEnlazada.size(); ++i)
            System.out.print(listaEnlazada.get(i).getCountry()+ " ");
        System.out.println();
    }

}
