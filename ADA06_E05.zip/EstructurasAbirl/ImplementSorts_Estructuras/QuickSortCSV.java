import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 * Clase que implementa el algoritmo de ordenamiento Quicksort en una lista
 * doblemente ligada.
 * 
 * 
 * @author Carlos Javier Calderon Delgado
 * @author Elias Madera de Regil
 * 
 * @version 1.0
 * @see CSVData
 * @see DoublyLinkedList
 * @see DoublyLink
 */
public class QuickSortCSV {
    /**
     * Lista doblemente enlazada donde se almacenan los datos del CSV y se realiza
     * el ordenamiento.
     */
    private DoublyLinkedList<CSVData> listaEnlazada;
    /**
     * String que define la columna por la que se va a ordenar
     * {@link listaEnlazada}.
     */
    private String columna;
    /**
     * Booleano que define si el ordenamiento sera de forma ascendente o descendente
     */
    private Boolean ascendente;
    /**
     * Integer que representa el numero de intercambios hechos durante el
     * ordenamiento
     */
    private int numeroDeIntercambios;
    /**
     * Integer que representa el numero de comparaciones hechas durante el
     * ordenamiento
     */
    private int numeroDeComparaciones;
    /**
     * Double que representa el tiempo de ordenamiento
     */
    private double tiempoDeEjecucion;

    /**
     * Constructor que recibe la columna a ordenar y el booleano que determina si es
     * ordenamiento ascendente o descendente.
     * 
     * @param columna
     * @param ascendente
     */
    public QuickSortCSV(String columna, Boolean ascendente) {
        this.columna = columna;
        this.ascendente = ascendente;
        listaEnlazada = new DoublyLinkedList<CSVData>();
        numeroDeIntercambios = 0;
        numeroDeComparaciones = 0;
    }

    /**
     * Metodo que recibe una linea del csv y retorna su representacion en
     * una instancia de {@link CSVData}
     * 
     * @param line
     * @return {@link CSVData}
     */
    private CSVData createCSVLink(String line) {
        String[] lineArray = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
        int serialNumber = Integer.parseInt(lineArray[0]);
        String country = lineArray[1];
        long[] restOfAttributes = new long[6];

        for (int i = 2; i < lineArray.length; i++) {
            if (lineArray[i].equals("") || lineArray[i].equals("N/A")) {
                restOfAttributes[i - 2] = 0;
            } else {
                String numberWithoutCommas = lineArray[i].replaceAll(",", "").replaceAll("\"", "");
                restOfAttributes[i - 2] = Long.parseLong((numberWithoutCommas));
            }
        }

        return new CSVData(serialNumber, country, restOfAttributes[0], restOfAttributes[1], restOfAttributes[2],
                restOfAttributes[3], restOfAttributes[4], restOfAttributes[5]);
    }

    /**
     * Metodo que recibe el nombre del archivo csv y lo carga en memoria
     * a traves de una lista doblemente ligada.
     * 
     * @param filename
     * @see createCSVLink
     * @see DoublyLinkedList
     * @see CSVData
     */
    public void loadCSV(String filename) {
        if (listaEnlazada.findFirst() != null)
            listaEnlazada.clear();

        File csvFile = new File(filename);
        try (Scanner csvReader = new Scanner(csvFile);) {
            csvReader.nextLine();
            while (csvReader.hasNext()) {
                String linea = csvReader.nextLine();
                CSVData newLink = createCSVLink(linea);
                listaEnlazada.insertAfter(newLink);
            }
            csvReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error: Archivo " + filename + " no encontrado");
        }
    }

    /**
     * Metodo encargado de exportar {@link listaEnlazada} en un archivo CSV
     * 
     */
    private void exportCSV() {
        File csvFile = new File("../csv's/QuickSort_ordenado.csv");
        try (FileWriter csvWriter = new FileWriter(csvFile);) {
            csvWriter.write(
                    "Serial Number,Country,Total Cases,Total Deaths,Tojavadoctal Recovered,Active Cases,Total Test,Population\n");
            DoublyLink<CSVData> curr = listaEnlazada.findFirst();
            while (curr.next != null) {
                csvWriter.write(curr.dData + "\n");
                curr = curr.next;
            }
            csvWriter.write(curr.dData.toString());
            csvWriter.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Metodo encargado de exportar {@link numeroDeIntercambios},
     * {@link numeroDeComparaciones} y {@link tiempoDeEjecucion} en un archivo txt
     */
    private void exportMetrics() {
        File metricsFile = new File("../metricas/Metricas.txt");
        try {
            FileWriter writer = new FileWriter(metricsFile, true);
            writer.write("Sort: QuickSort\n");
            writer.write("Tiempo de ejecucion: " + tiempoDeEjecucion + " segundos" + "\n");
            writer.write("Numero de comparaciones: " + numeroDeComparaciones + "\n");
            writer.write("Numero de intercambios: " + numeroDeIntercambios + "\n");
            writer.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

    /**
     * Ordenamiento de Quicksort en forma ascendente
     * 
     * @param primero
     * @param ultimo
     */
    private void quicksortAscendente(DoublyLink<CSVData> primero, DoublyLink<CSVData> ultimo) {
        if (ultimo != null && primero != ultimo && primero != ultimo.next) {
            DoublyLink<CSVData> pivote = particionAscendente(primero, ultimo);
            quicksortAscendente(primero, pivote.prev);
            quicksortAscendente(pivote.next, ultimo);
        }
    }

    /**
     * particion en forma ascendente
     * 
     * @param izquierda
     * @param derecha
     * @return
     */
    private DoublyLink<CSVData> particionAscendente(DoublyLink<CSVData> izquierda, DoublyLink<CSVData> derecha) {
        long pivote = derecha.dData.getAttribute(columna);
        DoublyLink<CSVData> i = izquierda.prev;
        for (DoublyLink<CSVData> j = izquierda; j != derecha; j = j.next) {
            if (j.dData.getAttribute(columna) <= pivote) {
                if (i == null) {
                    i = izquierda;
                } else {
                    i = i.next;
                }
                swap(i, j);
            }
            numeroDeComparaciones++;
        }
        if (i == null) {
            i = izquierda;
        } else {
            i = i.next;
        }
        swap(derecha, i);
        return i;
    }

    /**
     * Ordenamiento de Quicksort en forma ascendente
     * 
     * @param izquierda
     * @param derecha
     * @return
     */
    private void quicksortDescendente(DoublyLink<CSVData> primero, DoublyLink<CSVData> ultimo) {
        if (ultimo != null && primero != ultimo && primero != ultimo.next) {
            DoublyLink<CSVData> pivote = particionDescendente(primero, ultimo);
            quicksortDescendente(primero, pivote.prev);
            quicksortDescendente(pivote.next, ultimo);
        }
    }

    /**
     * particion en forma descendente
     * 
     * @param izquierda
     * @param derecha
     * @return {@link CSVData}
     */
    private DoublyLink<CSVData> particionDescendente(DoublyLink<CSVData> izquierda, DoublyLink<CSVData> derecha) {
        long pivote = derecha.dData.getAttribute(columna);
        DoublyLink<CSVData> i = izquierda.prev;
        for (DoublyLink<CSVData> j = izquierda; j != derecha; j = j.next) {
            if (j.dData.getAttribute(columna) >= pivote) {
                if (i == null) {
                    i = izquierda;
                } else {
                    i = i.next;
                }
                swap(i, j);
            }
            numeroDeComparaciones++;
        }
        if (i == null) {
            i = izquierda;
        } else {
            i = i.next;
        }
        swap(derecha, i);
        return i;
    }

    /**
     * Intercambia los datos de dos nodos.
     * 
     * @param nodo1
     * @param nodo2
     */
    private void swap(DoublyLink<CSVData> nodo1, DoublyLink<CSVData> nodo2) {
        CSVData aux = nodo1.dData;
        nodo1.dData = nodo2.dData;
        nodo2.dData = aux;
        numeroDeIntercambios++;
    }

    /**
     * Metodo encargado de ordenar segun {@link columna} y {@link ascendente}.
     * Posteriormente exporta las metricas a un archivo txt y {@link listaEnlazada}
     * la exporta a un archivo csv.
     */
    public void sort() {
        long tiempoDeInicio = System.nanoTime();
        DoublyLink<CSVData> primero = listaEnlazada.findFirst();
        DoublyLink<CSVData> ultimo = listaEnlazada.findLast();
        if (ascendente) {
            quicksortAscendente(primero, ultimo);
        } else {
            quicksortDescendente(primero, ultimo);
        }
        long tiempoFinal = System.nanoTime();

        tiempoDeEjecucion = (tiempoFinal - tiempoDeInicio) / 1E9;
        exportCSV();
        exportMetrics();
    }
}
