
/**
 * Lista Doblemente Enlazada con doble terminacion
 * 
 * 
 * @author Elias Madera de Regil y Carlos Javier Calderon Delgado
 * @version 1.0
 * @since 2022-02-27
 * @param <T> - Datos genericos
 */

public class DoublyLinkedList<T> {
    private DoublyLink<T> first;
    private DoublyLink<T> last;
    private int size;

    public DoublyLinkedList() {
        first = null;
        last = null;
        size = 0;
    }

    public void insertAfter(T dd) {

        DoublyLink<T> newLink = new DoublyLink<>(dd);
        if (isEmpty()) {
            first = newLink;

        } else {
            last.next = newLink;
            newLink.prev = last;
        }
        last = newLink;
        ++size;

    }

    public DoublyLink<T> deleteAfter() {

        if (isEmpty())
            return null;
        DoublyLink<T> newLast = last.prev;
        DoublyLink<T> deleted = last;
        if (newLast != null) {

            newLast.next = null;

        } else {

            first = null;

        }
        last = newLast;
        --size;

        return deleted;

    }

    public DoublyLink<T> find(T key) {

        DoublyLink<T> curr = first;
        while (curr != null) {

            if (curr.dData == key)
                return curr;

            curr = curr.next;

        }

        return curr;

    }

    public DoublyLink<T> remove(T key) {

        DoublyLink<T> curr = first;
        while (curr != null) {

            if (curr.dData == key) {

                if (curr.prev != null) {

                    curr.prev.next = curr.next;
                    if (curr == last) {
                        last = curr.prev;
                    } else {
                        curr.next.prev = curr.prev;
                    }

                } else {

                    first = curr.next;
                    if (curr.next != null) {

                        curr.next.prev = null;

                    }

                }
                --size;
                break;

            }
            curr = curr.next;

        }

        return curr;

    }

    public boolean isEmpty() {
        return (first == null);
    }

    public void insertFirst(T dd) {
        DoublyLink<T> newLink = new DoublyLink<>(dd);
        if (isEmpty()) {
            last = newLink;
        } else {
            first.prev = newLink;
        }
        newLink.next = first;
        first = newLink;
        ++size;
    }

    public DoublyLink<T> deleteFirst() {
        DoublyLink<T> temp = null;
        if (!isEmpty()) {
            temp = first;
            first = first.next;

            if (isEmpty()) {
                last = null;
            } else {
                first.prev = null;
            }
            --size;
        }
        return temp;
    }

    public void displayList() {
        System.out.print("List (first--> ");
        DoublyLink<T> current = first;
        while (current != null) {
            current.displayLink();
            current = current.next;
        }
        System.out.println("<--last)");
    }

    public DoublyLink<T> deleteAt(int index) {

        DoublyLink<T> curr = first;
        int i = -1;
        while (curr != null) {

            if (++i == index) {

                if (curr.prev != null) {

                    curr.prev.next = curr.next;
                    if (curr == last)
                        last = curr.prev;

                } else {

                    first = curr.next;
                    if (curr.next != null) {

                        curr.next.prev = null;

                    }

                }
                --size;
                break;

            }
            curr = curr.next;

        }

        return curr;

    }

    public DoublyLink<T> findFirst() {

        return first;

    }

    public DoublyLink<T> findLast() {

        return last;

    }

    public int getSize() {

        return size;

    }

    public void update(T oldData, T newData) {

        DoublyLink<T> curr = first;
        while (curr != null) {

            if (curr.dData == oldData) {
                curr.dData = newData;
                return;
            }
            curr = curr.next;
        }

    }

    public void updateAt(T newData, int index) {

        DoublyLink<T> curr = first;
        for (int i = 0; curr != null; ++i, curr = curr.next)
            if (i == index)
                curr.dData = newData;

    }

    public int getIndex(T dd) {
        DoublyLink<T> curr = first;
        int i = 0;
        while (curr.dData != dd) {
            i++;
            curr = curr.next;
        }
        return i;
    }

    public DoublyLink<T> get(int index) {
        DoublyLink<T> curr = first;
        int i = 0;
        while (i != index) {
            curr = curr.next;
            i++;
        }

        return curr;

    }

    public void clear() {

        first = null;
        last = null;
        size = 0;

    }

}