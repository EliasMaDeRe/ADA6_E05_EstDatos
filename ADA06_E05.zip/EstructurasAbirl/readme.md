### Instrucciones para ejectuar el programa:

### Entrar a la carpeta ImplementSorts_Estructuras del archivo descargado

### correr el comando 'javac *.java' en la terminal

### correr el comando 'java app' en la terminal

### Seguir las instrucciones en pantalla para escoger el método de ordenamiento y columna del csv original para ordenar

### Observar los resultas en la carpeta de csv's y las métricas en la carpeta de métricas.